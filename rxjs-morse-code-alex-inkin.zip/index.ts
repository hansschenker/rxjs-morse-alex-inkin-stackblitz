import './style.css';

import {
  map,
  fromEvent,
  switchMap,
  filter,
  reduce,
  takeUntil,
  timer,
  repeat,
} from 'rxjs';

const up$ = fromEvent(document, 'keyup').pipe(map((e) => e.timeStamp));
const down$ = fromEvent<KeyboardEvent>(document, 'keydown').pipe(
  filter((e) => !e.repeat),
  map((e) => e.timeStamp)
);

down$
  .pipe(
    switchMap((start) => up$.pipe(map((end) => end - start))),
    map((duration) => (duration > 100 ? '-' : '.')),
    takeUntil(timer(1000).pipe(takeUntil(down$), repeat())),
    reduce((acc, char) => acc + char, ''),
    filter(Boolean),
    repeat()
  )
  .subscribe(console.log);
